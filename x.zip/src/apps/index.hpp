#pragma once

#include <vector>
#include <algorithm>
#include <Arduino.h>

#include "functions.hpp"
#include "sandbox.hpp"
#include "network.hpp"
#include "runtime.hpp"
#include "app.hpp"
#include "system.hpp"
#include "windows.hpp"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
// semphr.h wird nicht mehr benötigt, da wir keinen Mutex verwenden
#include "esp_system.h"

#include "../wifi/index.hpp"

// ---------------------- Globals ----------------------
TaskHandle_t WindowAppRenderHandle = NULL;

// Wir schützen runningTasks mit einem ESP32-Spinlock (Critical Section),
// damit es keine Owner-Asserts wie bei Mutexen gibt.
#if CONFIG_IDF_TARGET_ESP32 || CONFIG_IDF_TARGET_ESP32S2 || CONFIG_IDF_TARGET_ESP32S3 || CONFIG_IDF_TARGET_ESP32C3
static portMUX_TYPE runningTasksLock = portMUX_INITIALIZER_UNLOCKED;
#else
static portMUX_TYPE runningTasksLock; // Fallback
#endif

static std::vector<TaskHandle_t> runningTasks;

// Kurze Hilfsmakros für atomare Zugriffe
#define RUNNING_TASKS_LOCK() taskENTER_CRITICAL(&runningTasksLock)
#define RUNNING_TASKS_UNLOCK() taskEXIT_CRITICAL(&runningTasksLock)

// ---------------------- Helpers: runningTasks ----------------------

// Füge Taskhandle (einmalig) ein
static void addRunningTask(TaskHandle_t h)
{
    if (!h)
        return;
    RUNNING_TASKS_LOCK();
    if (std::find(runningTasks.begin(), runningTasks.end(), h) == runningTasks.end())
        runningTasks.push_back(h);
    RUNNING_TASKS_UNLOCK();
}

// Entferne Taskhandle, wenn vorhanden
static void removeRunningTask(TaskHandle_t h)
{
    if (!h)
        return;
    RUNNING_TASKS_LOCK();
    auto it = std::find(runningTasks.begin(), runningTasks.end(), h);
    if (it != runningTasks.end())
        runningTasks.erase(it);
    RUNNING_TASKS_UNLOCK();
}

// ---------------------- App Run Task ----------------------
//
// Erwartet in pvParameters einen Zeiger auf eine heap-allokierte std::vector<String>
// args[0] = App-Pfad; args[1..] = App-Argumente
//
void AppRunTask(void *pvParameters)
{
    auto taskArgsPtr = static_cast<std::vector<String> *>(pvParameters);
    std::vector<String> args = *taskArgsPtr;
    delete taskArgsPtr; // Übergabe-Speicher freigeben

    // Ab jetzt "läuft" der Task und gehört in die Liste
    addRunningTask(xTaskGetCurrentTaskHandle());

    Serial.println("Running Lua app...");

    std::vector<String> appArgs;
    if (args.size() > 1)
        appArgs.assign(args.begin() + 1, args.end());

    // App ausführen
    int result = LuaApps::runApp(args[0], appArgs);
    Serial.printf("Lua App exited with code: %d\n", result);

    // Sich selbst aus der Liste entfernen und beenden
    removeRunningTask(xTaskGetCurrentTaskHandle());
    vTaskDelete(NULL);
}

// ---------------------- Start application in a new task ----------------------
//
// args wird kopiert und die Kopie (heap) in den Task übergeben.
//
void executeApplication(const std::vector<String> &args)
{
    if (args.empty())
    {
        Serial.println("ERROR: no execute path specified");
        return;
    }

    // Heap-allokierte Kopie der Argumente. AppRunTask löscht sie.
    auto taskArgsPtr = new std::vector<String>(args);

    TaskHandle_t WindowAppRunHandle = NULL;
    BaseType_t res = xTaskCreate(
        AppRunTask,         // task function
        "AppRunTask",       // name
        2048 * 6,           // stack (words) -> erhöht für Stabilität
        taskArgsPtr,        // parameter (heap-allocated copy)
        1,                  // priority
        &WindowAppRunHandle // task handle (optional)
    );

    if (res != pdPASS)
    {
        Serial.println("ERROR: failed to create AppRunTask");
        delete taskArgsPtr; // bei Fehler Speicher freigeben
        return;
    }

    // Wichtig: wir fügen den Task **nicht** hier ein.
    // addRunningTask() passiert im Task selbst, sobald er wirklich läuft.
}

// ---------------------- Persistent Render Task ----------------------
void AppRenderTask(void *pvParameters)
{
    (void)pvParameters;

    // Render-Task in die Liste aufnehmen
    addRunningTask(xTaskGetCurrentTaskHandle());

    while (true)
    {
        Windows::loop();
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void startWindowRender()
{
    // Falls bereits gestartet, nicht nochmal starten
    if (WindowAppRenderHandle != NULL)
    {
        eTaskState s = eTaskGetState(WindowAppRenderHandle);
        if (s != eDeleted)
        {
            Serial.println("AppRenderTask already running");
            return;
        }
        // Falls gelöscht, Handle zurücksetzen
        WindowAppRenderHandle = NULL;
    }

    BaseType_t res = xTaskCreate(
        AppRenderTask,
        "AppRenderTask",
        4096, // etwas größerer Stack
        NULL,
        2, // etwas höhere Prio als App-Tasks
        &WindowAppRenderHandle);

    if (res != pdPASS)
    {
        Serial.println("ERROR: failed to create AppRenderTask");
        WindowAppRenderHandle = NULL;
        return;
    }

    // Kein addRunningTask() hier -> macht der Task selbst am Anfang
}

// ---------------------- Task Monitor ----------------------
//
// Druckt High-Water-Marks aller bekannten Tasks,
// bereinigt gelöschte Tasks und loggt freien Heap.
//
void TaskMonitor(void *pvParameters)
{
    (void)pvParameters;

    for (;;)
    {
        // Globaler Heap-Status
        Serial.printf("[TaskMonitor] Free heap: %u bytes, MaxAlloc: %u bytes\n",
                      ESP.getFreeHeap(), ESP.getMaxAllocHeap());

        // Schnappschuss der Handles unter kurzer Critical-Section
        std::vector<TaskHandle_t> snapshot;
        RUNNING_TASKS_LOCK();
        snapshot = runningTasks;
        RUNNING_TASKS_UNLOCK();

        // Außerhalb der Critical-Section über Handles iterieren
        for (TaskHandle_t h : snapshot)
        {
            if (!h)
                continue;

            eTaskState state = eTaskGetState(h);

            if (state == eDeleted)
            {
                // Aus der echten Liste entfernen und melden
                removeRunningTask(h);
                Serial.printf("Task %p state=DELETED -> removed\n", (void *)h);
                continue;
            }

            // High-Water-Mark abfragen
            UBaseType_t highWords = uxTaskGetStackHighWaterMark(h);
            unsigned int highBytes = (unsigned int)(highWords * sizeof(StackType_t));
            UBaseType_t prio = uxTaskPriorityGet(h);

            // Optionale Namensausgabe (wenn verfügbar)
            const char *name = pcTaskGetTaskName(h);
            if (name == nullptr)
                name = "?";

            Serial.printf("Task %p name=%s prio=%u state=%d highWater=%u bytes\n",
                          (void *)h, name, (unsigned)prio, (int)state, highBytes);
        }

        // Einmal pro Sekunde
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

void startTaskMonitor(unsigned priority = 1)
{
    // Nur einen Monitor starten
    static TaskHandle_t monitorHandle = NULL;

    if (monitorHandle != NULL)
    {
        eTaskState s = eTaskGetState(monitorHandle);
        if (s != eDeleted)
        {
            Serial.println("TaskMonitor already running");
            return;
        }
        monitorHandle = NULL;
    }

    BaseType_t res = xTaskCreate(
        TaskMonitor,
        "TaskMonitor",
        3072, // moderater Stack
        NULL,
        priority,
        &monitorHandle);

    if (res != pdPASS)
    {
        Serial.println("ERROR: failed to create TaskMonitor");
        return;
    }

    // Der Monitor taucht in der Liste auf, sobald er addRunningTask() ruft?
    // -> Nein, der Monitor verwaltet andere Tasks und muss selbst nicht
    // in runningTasks erscheinen. Wenn gewünscht, hier einkommentieren:
    // addRunningTask(monitorHandle);
}

// ---------------------- Debug (single-shot) ----------------------
void debugTaskLog()
{
    Serial.println("Min,Nor,Max");
    Serial.println(ESP.getMinFreeHeap());
    Serial.println(ESP.getFreeHeap());
    Serial.println(ESP.getMaxAllocHeap());

    if (WindowAppRenderHandle)
    {
        Serial.printf("AppRenderTask free stack: %u bytes\n",
                      (unsigned int)(uxTaskGetStackHighWaterMark(WindowAppRenderHandle) * sizeof(StackType_t)));
    }
    else
    {
        Serial.println("AppRenderTask handle not set");
    }

    // Optional: Alle bekannten Tasks einmalig loggen
    std::vector<TaskHandle_t> snapshot;
    RUNNING_TASKS_LOCK();
    snapshot = runningTasks;
    RUNNING_TASKS_UNLOCK();

    for (TaskHandle_t h : snapshot)
    {
        if (!h)
            continue;
        UBaseType_t highWords = uxTaskGetStackHighWaterMark(h);
        unsigned int highBytes = (unsigned int)(highWords * sizeof(StackType_t));
        const char *name = pcTaskGetTaskName(h);
        if (!name)
            name = "?";
        Serial.printf("[debugTaskLog] Task %p name=%s highWater=%u bytes\n",
                      (void *)h, name, highBytes);
    }
}
